
<?php


$this->widget('kbcategorize', array(
	'back_url'=>'index.php?r=alms/kb/show',
	'original_name'=>'my test',
	'res_id'=>1,
));


?>