
<?php

Util::widget('kbcategorize', array(
		'original_name'=>'',
		'back_url'=>'index.php?r=alms/kb/show',
		'form_url'=>'index.php?r=alms/kb/edit&amp;id='.$res_id,
		'res_id'=>$res_id,
	));

?>