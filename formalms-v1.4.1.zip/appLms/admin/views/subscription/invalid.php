<div class="std_block">
	<p>
		<?php echo $message; ?>
	</p>
	<?php echo getBackUi($back_url, Lang::t('_BACK', 'standard')); ?>
</div>