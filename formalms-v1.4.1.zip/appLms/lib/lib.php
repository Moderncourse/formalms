<?php defined("IN_FORMA") or die('Direct access is forbidden.');

/* ======================================================================== \
|   FORMA - The E-Learning Suite                                            |
|                                                                           |
|   Copyright (c) 2013 (Forma)                                              |
|   http://www.formalms.org                                                 |
|   License  http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt           |
|                                                                           |
|   from docebo 4.0.5 CE 2008-2012 (c) docebo                               |
|   License http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt            |
\ ======================================================================== */

require_once($GLOBALS['where_lms'].'/lib/lib.track_user.php');

//require_once(_i18n_.'/lib.lang.php');
require_once(_base_.'/lib/lib.template.php');
require_once(_base_.'/lib/lib.mimetype.php');

require_once($GLOBALS['where_lms'].'/lib/lib.permission.php');
require_once($GLOBALS['where_lms'].'/lib/lib.module.php');

require_once(_base_.'/lib/lib.donotdo.php');
//require_once(_base_.'/lib/lib.utils.php');
require_once($GLOBALS['where_lms'].'/lib/lib.utils.php'); 
require_once($GLOBALS['where_framework'].'/lib/logger.php');


?>